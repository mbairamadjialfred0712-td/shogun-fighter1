
const seed = {
  user: { name: "Kodjo Amegan", initials: "KA", city: "Lomé, Togo" },
  members: [
    { id: 1, name: "Kodjo Amegan", phone: "+228 90 00 00 01", activity: "Karaté", plan: "Mensuel", status: "Actif", expires: "2026-09-28" },
    { id: 2, name: "Mawuli Kossi", phone: "+228 90 00 00 02", activity: "Gym", plan: "Mensuel", status: "Actif", expires: "2026-09-18" },
    { id: 3, name: "Akouvi Sena", phone: "+228 90 00 00 03", activity: "Danse", plan: "Trimestriel", status: "Actif", expires: "2026-10-12" },
    { id: 4, name: "Yao Mensah", phone: "+228 90 00 00 04", activity: "Karaté", plan: "Mensuel", status: "À renouveler", expires: "2026-09-11" },
    { id: 5, name: "Afi Dovi", phone: "+228 90 00 00 05", activity: "Gym", plan: "Mensuel", status: "Actif", expires: "2026-09-30" },
    { id: 6, name: "Koffi Assou", phone: "+228 90 00 00 06", activity: "Danse", plan: "Mensuel", status: "Actif", expires: "2026-09-25" },
    { id: 7, name: "Elom Tété", phone: "+228 90 00 00 07", activity: "Karaté", plan: "Annuel", status: "Actif", expires: "2027-02-02" },
    { id: 8, name: "Mélanie K.", phone: "+228 90 00 00 08", activity: "Gym", plan: "Mensuel", status: "Actif", expires: "2026-09-20" }
  ],
  payments: [
    { id: 101, member: "Kodjo Amegan", amount: 10000, date: "2026-09-11", method: "Espèces", type: "Abonnement" },
    { id: 102, member: "Mawuli Kossi", amount: 10000, date: "2026-09-11", method: "TMoney", type: "Abonnement" },
    { id: 103, member: "Akouvi Sena", amount: 30000, date: "2026-09-10", method: "Flooz", type: "Abonnement" },
    { id: 104, member: "Yao Mensah", amount: 10000, date: "2026-09-10", method: "Espèces", type: "Abonnement" }
  ],
  activities: [
    { id: 1, name: "Karaté", members: 14, schedule: "Lun / Mer / Ven — 18h00" },
    { id: 2, name: "Gym", members: 11, schedule: "Mar / Jeu — 17h30" },
    { id: 3, name: "Danse", members: 8, schedule: "Sam — 15h00" }
  ]
};

let db = JSON.parse(localStorage.getItem("shogun-fighters-db") || "null") || seed;
function save(){ localStorage.setItem("shogun-fighters-db", JSON.stringify(db)); }
function money(n){ return new Intl.NumberFormat("fr-FR").format(n) + " FCFA"; }
function dateFr(v){ return new Intl.DateTimeFormat("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"}).format(new Date(v+"T00:00:00")); }
function uid(){ return Date.now() + Math.floor(Math.random()*999); }

const icons = {
  home:`<svg viewBox="0 0 24 24"><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/></svg>`,
  users:`<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 5.5a3 3 0 0 1 0 5.8M18 14.5a5.8 5.8 0 0 1 3 5.5"/></svg>`,
  calendar:`<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M8 2v4M16 2v4M3 9h18"/><path d="M8 13h3M8 17h6"/></svg>`,
  wallet:`<svg viewBox="0 0 24 24"><path d="M4 5h15a2 2 0 0 1 2 2v12H5a2 2 0 0 1-2-2V6a1 1 0 0 1 1-1Z"/><path d="M3 8h16"/><path d="M16 13h5v4h-5a2 2 0 1 1 0-4Z"/></svg>`,
  menu:`<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`,
  plus:`<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>`,
  refresh:`<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 0 0-14.8-4L3 10"/><path d="M3 5v5h5"/><path d="M4 13a8 8 0 0 0 14.8 4L21 14"/><path d="M21 19v-5h-5"/></svg>`,
  check:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>`,
  alert:`<svg viewBox="0 0 24 24"><path d="m12 3 9 17H3L12 3Z"/><path d="M12 9v4M12 16h.01"/></svg>`,
  receipt:`<svg viewBox="0 0 24 24"><path d="M5 3h14v18l-3-2-4 2-4-2-3 2V3Z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>`,
  activity:`<svg viewBox="0 0 24 24"><path d="M4 17h4l2-10 4 14 2-8h4"/></svg>`,
  bell:`<svg viewBox="0 0 24 24"><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>`,
  chart:`<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>`,
  settings:`<svg viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/><path d="m19.4 15 .1.1 1.7 1.3-2 3.4-2-.8a8 8 0 0 1-2 1.1L15 22h-4l-.3-2a8 8 0 0 1-2-1.1l-2 .8-2-3.4L6.4 15a8 8 0 0 1 0-2L4.7 11.7l2-3.4 2 .8a8 8 0 0 1 2-1.1L11 6h4l.3 2a8 8 0 0 1 2 1.1l2-.8 2 3.4-1.7 1.3a8 8 0 0 1-.2 2Z"/></svg>`,
  arrow:`<svg viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></svg>`,
  close:`<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>`,
  search:`<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></svg>`
};
function icon(name){ return `<span class="icon">${icons[name]||""}</span>`; }

const nav = [
  ["dashboard","Accueil","home"],
  ["members","Membres","users"],
  ["subscriptions","Abonnements","calendar"],
  ["payments","Paiements","wallet"],
  ["more","Plus","menu"]
];

function route(){ return location.hash.replace("#/","") || "dashboard"; }
function setRoute(r){ location.hash = "#/"+r; }

function sidebar(){
  const active=route();
  return `<aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="brand-mark">SF</div>
      <div><strong>Shogun Fighters</strong><small>Association sportive</small></div>
    </div>
    <nav>${nav.map(([r,l,i])=>`<button class="nav-item ${active===r||(["activities","receipts","notifications","entries","statistics","settings"].includes(active)&&r==="more")?"active":""}" data-route="${r}">${icon(i)}<span>${l}</span>${r==="more"?'<b class="badge">3</b>':""}</button>`).join("")}</nav>
    <div class="sidebar-user">
      <div class="avatar">KA</div><div><strong>Kodjo Amegan</strong><small>Lomé, Togo</small></div>
    </div>
  </aside>`;
}

function header(title,subtitle){
  return `<header class="topbar">
    <div><button class="mobile-menu" id="mobile-menu">${icon("menu")}</button><h1>${title}</h1><p>${subtitle}</p></div>
    <div class="top-actions"><button class="icon-btn" title="Notifications" data-route="notifications">${icon("bell")}</button><div class="avatar small">KA</div></div>
  </header>`;
}

function stat(label,value,kind,iconName){
  return `<div class="stat"><div class="stat-icon ${kind}">${icon(iconName)}</div><div><strong>${value}</strong><span>${label}</span></div></div>`;
}

function dashboard(){
  const active=db.members.filter(m=>m.status==="Actif").length;
  const renew=db.members.filter(m=>m.status!=="Actif").length;
  const today=db.payments.filter(p=>p.date==="2026-09-11").reduce((s,p)=>s+p.amount,0);
  return `<div class="page">${header(`Bonjour ${db.user.name} 👋`,"Voici votre salle en un coup d’œil.")}
    <div class="stats">${stat("Membres",db.members.length,"purple","users")}${stat("Abonnements actifs",active,"green","check")}${stat("À renouveler",renew,"orange","alert")}${stat("Aujourd’hui",money(today),"pink","wallet")}</div>
    <div class="quick-actions">
      <button class="primary" data-modal="member">${icon("plus")}Ajouter un membre</button>
      <button data-modal="renew">${icon("refresh")}Renouveler un abonnement</button>
      <button data-modal="payment">${icon("wallet")}Enregistrer un paiement</button>
    </div>
    <section class="panel menu-panel">
      <div class="panel-head gradient"><div><h2>Menu principal</h2><p>Choisissez ce que vous voulez faire</p></div></div>
      <div class="action-grid">
        ${action("members","users","Voir les membres","Qui sont mes membres ?","purple")}
        ${action("subscriptions","calendar","Voir les abonnements","Qui est encore abonné ?","green")}
        ${action("payments","wallet","Voir les paiements","Qui a payé ?","pink")}
        ${action("receipts","receipt","Reçus","Imprimer un reçu","green")}
        ${action("activities","activity","Activités","Gym, Karaté, Danse...","purple")}
        ${action("notifications","bell","Notifications","Rappels d’expiration","orange")}
        ${action("entries","refresh","Entrées et sorties","Argent entré et sorti","pink")}
        ${action("statistics","chart","Statistiques","Comment fonctionne ma salle ?","orange")}
        ${action("settings","settings","Paramètres","Modifier mon espace","gray")}
      </div>
      <div class="license">Licence accordée à <strong>SHOGUN FIGHTERS</strong></div>
    </section>
  </div>`;
}
function action(r,i,t,s,c){ return `<button class="action-card" data-route="${r}"><span class="action-icon ${c}">${icon(i)}</span><span><strong>${t}</strong><small>${s}</small></span>${icon("arrow")}</button>`; }

function members(){
  return `<div class="page">${header("Membres","Gérez les adhérents de votre association.")}
    <div class="toolbar"><button class="primary" data-modal="member">${icon("plus")}Ajouter un membre</button><div class="search">${icon("search")}<input id="member-search" placeholder="Rechercher un membre..."></div></div>
    <section class="panel"><div class="table-wrap"><table><thead><tr><th>Membre</th><th>Activité</th><th>Formule</th><th>Expiration</th><th>Statut</th><th></th></tr></thead><tbody id="members-body">${memberRows(db.members)}</tbody></table></div></section>
  </div>`;
}
function memberRows(items){ return items.map(m=>`<tr><td><div class="person"><span class="avatar mini">${m.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span><div><strong>${m.name}</strong><small>${m.phone}</small></div></div></td><td>${m.activity}</td><td>${m.plan}</td><td>${dateFr(m.expires)}</td><td><span class="status ${m.status==="Actif"?"ok":"warning"}">${m.status}</span></td><td><button class="more-btn" data-member="${m.id}">•••</button></td></tr>`).join("") || `<tr><td colspan="6" class="empty">Aucun membre trouvé.</td></tr>`; }

function subscriptions(){
  const active=db.members.filter(m=>m.status==="Actif").length;
  const renew=db.members.length-active;
  return `<div class="page">${header("Abonnements","Suivez les formules et les renouvellements.")}
    <div class="stats compact">${stat("Actifs",active,"green","check")}${stat("À renouveler",renew,"orange","alert")}${stat("Formules","3","purple","calendar")}</div>
    <section class="panel"><div class="panel-head"><div><h2>Suivi des abonnements</h2><p>Les dates proches sont signalées automatiquement.</p></div><button class="primary" data-modal="renew">${icon("refresh")}Renouveler</button></div>
    <div class="subscription-list">${db.members.map(m=>`<div class="subscription"><div class="person"><span class="avatar mini">${m.name.slice(0,2).toUpperCase()}</span><div><strong>${m.name}</strong><small>${m.plan} · ${m.activity}</small></div></div><div class="subscription-date"><small>Expire le</small><strong>${dateFr(m.expires)}</strong></div><span class="status ${m.status==="Actif"?"ok":"warning"}">${m.status}</span></div>`).join("")}</div></section>
  </div>`;
}

function payments(){
  const total=db.payments.reduce((s,p)=>s+p.amount,0);
  return `<div class="page">${header("Paiements","Enregistrez et consultez les recettes de la salle.")}
    <div class="stats compact">${stat("Total enregistré",money(total),"pink","wallet")}${stat("Transactions",db.payments.length,"purple","receipt")}${stat("Moyens","3","green","check")}</div>
    <div class="toolbar"><button class="primary" data-modal="payment">${icon("plus")}Enregistrer un paiement</button></div>
    <section class="panel"><div class="table-wrap"><table><thead><tr><th>Membre</th><th>Type</th><th>Date</th><th>Moyen</th><th>Montant</th><th></th></tr></thead><tbody>${db.payments.map(p=>`<tr><td><strong>${p.member}</strong></td><td>${p.type}</td><td>${dateFr(p.date)}</td><td>${p.method}</td><td><strong>${money(p.amount)}</strong></td><td><button class="more-btn" data-receipt="${p.id}">Reçu</button></td></tr>`).join("")}</tbody></table></div></section>
  </div>`;
}

function activities(){
  return `<div class="page">${header("Activités","Organisez les activités proposées par Shogun Fighters.")}
    <section class="cards-3">${db.activities.map(a=>`<article class="feature-card"><div class="feature-icon purple">${icon("activity")}</div><h3>${a.name}</h3><p>${a.schedule}</p><strong>${a.members} membres</strong></article>`).join("")}</section>
  </div>`;
}

function receipts(){
  return `<div class="page">${header("Reçus","Retrouvez et imprimez les reçus de paiement.")}
    <section class="panel"><div class="receipt-list">${db.payments.map(p=>`<div class="receipt-row"><div><strong>Reçu #${String(p.id).slice(-5)}</strong><small>${p.member} · ${dateFr(p.date)}</small></div><strong>${money(p.amount)}</strong><button class="primary small-btn" data-receipt="${p.id}">Imprimer</button></div>`).join("")}</div></section>
  </div>`;
}

function notifications(){
  const soon=db.members.filter(m=>m.status!=="Actif" || m.expires <= "2026-09-20");
  return `<div class="page">${header("Notifications","Anticipez les expirations et les actions importantes.")}
    <section class="panel"><div class="notification-list">${soon.map(m=>`<div class="notification"><span class="action-icon orange">${icon("bell")}</span><div><strong>${m.name}</strong><p>Abonnement à surveiller — expiration le ${dateFr(m.expires)}.</p></div><button class="outline" data-modal="renew">Renouveler</button></div>`).join("") || '<div class="empty">Aucune notification urgente.</div>'}</div></section>
  </div>`;
}

function entries(){
  const inTotal=db.payments.reduce((s,p)=>s+p.amount,0);
  return `<div class="page">${header("Entrées et sorties","Visualisez simplement les mouvements financiers.")}
    <div class="stats compact">${stat("Entrées",money(inTotal),"green","wallet")}${stat("Sorties",money(0),"pink","refresh")}${stat("Solde",money(inTotal),"purple","chart")}</div>
    <section class="panel"><div class="panel-head"><div><h2>Journal financier</h2><p>Prototype : les sorties pourront être ajoutées dans la prochaine version.</p></div></div><div class="empty-state">${icon("wallet")}<h3>Tout est sous contrôle</h3><p>Aucune sortie enregistrée pour le moment.</p></div></section>
  </div>`;
}

function statistics(){
  const total=db.payments.reduce((s,p)=>s+p.amount,0);
  const max=Math.max(...db.activities.map(a=>a.members));
  return `<div class="page">${header("Statistiques","Une vue rapide de la performance de votre salle.")}
    <div class="stats compact">${stat("Membres",db.members.length,"purple","users")}${stat("Recettes",money(total),"green","wallet")}${stat("Activité principale",db.activities.find(a=>a.members===max)?.name||"—","orange","activity")}</div>
    <section class="panel chart-panel"><div class="panel-head"><div><h2>Répartition par activité</h2><p>Nombre de membres par activité.</p></div></div>${db.activities.map(a=>`<div class="bar-row"><div><strong>${a.name}</strong><span>${a.members}</span></div><div class="bar"><i style="width:${Math.max(12,(a.members/max)*100)}%"></i></div></div>`).join("")}</section>
  </div>`;
}

function settings(){
  return `<div class="page">${header("Paramètres","Personnalisez votre espace de gestion.")}
    <section class="settings-grid"><div class="panel"><h2>Informations de la salle</h2><label>Nom de la salle<input id="setting-name" value="Shogun Fighters"></label><label>Responsable<input value="${db.user.name}"></label><label>Ville<input value="${db.user.city}"></label><button class="primary" id="save-settings">Enregistrer</button></div>
    <div class="panel"><h2>Préférences</h2><div class="toggle-row"><div><strong>Notifications d’expiration</strong><small>Afficher les rappels dans le tableau de bord.</small></div><input type="checkbox" checked></div><div class="toggle-row"><div><strong>Mode simplifié</strong><small>Interface optimisée pour une utilisation rapide.</small></div><input type="checkbox"></div></div></section>
  </div>`;
}

function more(){
  return `<div class="page">${header("Plus","Accédez aux outils complémentaires de gestion.")}
    <section class="action-grid single">${action("activities","activity","Activités","Gym, Karaté, Danse...","purple")}${action("receipts","receipt","Reçus","Imprimer un reçu","green")}${action("notifications","bell","Notifications","Rappels d’expiration","orange")}${action("entries","refresh","Entrées et sorties","Argent entré et sorti","pink")}${action("statistics","chart","Statistiques","Comment fonctionne ma salle ?","orange")}${action("settings","settings","Paramètres","Modifier mon espace","gray")}</section>
  </div>`;
}

function render(){
  const r=route();
  const pages={dashboard,members,subscriptions,payments,activities,receipts,notifications,entries,statistics,settings,more};
  const content=(pages[r]||dashboard)();
  document.getElementById("app").innerHTML=`<div class="app-shell">${sidebar()}<main>${content}</main></div>${modalShell()}`;
  bind();
}
function modalShell(){ return `<div id="modal" class="modal-backdrop hidden"><div class="modal"><button class="close" id="modal-close">${icon("close")}</button><div id="modal-content"></div></div></div>`; }

function openModal(type){
  const m=document.getElementById("modal"), c=document.getElementById("modal-content");
  if(type==="member") c.innerHTML=`<h2>Ajouter un membre</h2><p>Créez rapidement une fiche adhérent.</p><form id="member-form"><label>Nom complet<input name="name" required placeholder="Ex. Kossi Mensah"></label><label>Téléphone<input name="phone" placeholder="+228 ..."></label><label>Activité<select name="activity"><option>Karaté</option><option>Gym</option><option>Danse</option></select></label><label>Formule<select name="plan"><option>Mensuel</option><option>Trimestriel</option><option>Annuel</option></select></label><label>Expiration<input name="expires" type="date" value="2026-10-11"></label><button class="primary full" type="submit">Ajouter le membre</button></form>`;
  if(type==="payment") c.innerHTML=`<h2>Enregistrer un paiement</h2><p>Associez un paiement à un membre.</p><form id="payment-form"><label>Membre<select name="member">${db.members.map(x=>`<option>${x.name}</option>`).join("")}</select></label><label>Montant<input name="amount" type="number" min="0" value="10000" required></label><label>Moyen<select name="method"><option>Espèces</option><option>TMoney</option><option>Flooz</option></select></label><button class="primary full" type="submit">Enregistrer le paiement</button></form>`;
  if(type==="renew") c.innerHTML=`<h2>Renouveler un abonnement</h2><p>Prolongez l’abonnement d’un membre.</p><form id="renew-form"><label>Membre<select name="id">${db.members.map(x=>`<option value="${x.id}">${x.name} — ${x.activity}</option>`).join("")}</select></label><label>Nouvelle date d’expiration<input name="expires" type="date" value="2026-10-11"></label><button class="primary full" type="submit">Renouveler</button></form>`;
  m.classList.remove("hidden");
  document.getElementById("modal-close").onclick=()=>m.classList.add("hidden");
  document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")m.classList.add("hidden")};
  const mf=document.getElementById("member-form"); if(mf) mf.onsubmit=e=>{e.preventDefault();const f=new FormData(mf);db.members.push({id:uid(),name:f.get("name"),phone:f.get("phone"),activity:f.get("activity"),plan:f.get("plan"),status:"Actif",expires:f.get("expires")});save();m.classList.add("hidden");render();};
  const pf=document.getElementById("payment-form"); if(pf) pf.onsubmit=e=>{e.preventDefault();const f=new FormData(pf);db.payments.unshift({id:uid(),member:f.get("member"),amount:Number(f.get("amount")),date:"2026-09-11",method:f.get("method"),type:"Abonnement"});save();m.classList.add("hidden");render();};
  const rf=document.getElementById("renew-form"); if(rf) rf.onsubmit=e=>{e.preventDefault();const f=new FormData(rf);const x=db.members.find(v=>String(v.id)===String(f.get("id")));if(x){x.expires=f.get("expires");x.status="Actif";}save();m.classList.add("hidden");render();};
}

function printReceipt(id){
  const p=db.payments.find(x=>String(x.id)===String(id)); if(!p)return;
  const w=window.open("","_blank","width=520,height=680");
  w.document.write(`<html><head><title>Reçu #${p.id}</title><style>body{font-family:Arial;padding:40px;color:#20233a}h1{margin-bottom:4px}.box{border:1px solid #ddd;padding:24px;border-radius:16px;margin-top:25px}strong{float:right}</style></head><body><h1>SHOGUN FIGHTERS</h1><p>Reçu de paiement</p><div class="box"><p>Reçu <strong>#${p.id}</strong></p><p>Membre <strong>${p.member}</strong></p><p>Date <strong>${dateFr(p.date)}</strong></p><p>Moyen <strong>${p.method}</strong></p><hr><h2>Total <strong>${money(p.amount)}</strong></h2></div><p>Merci pour votre confiance.</p><script>window.print()<\/script></body></html>`); w.document.close();
}

function bind(){
  document.querySelectorAll("[data-route]").forEach(b=>b.onclick=()=>{setRoute(b.dataset.route);document.getElementById("sidebar")?.classList.remove("open")});
  document.querySelectorAll("[data-modal]").forEach(b=>b.onclick=()=>openModal(b.dataset.modal));
  document.querySelectorAll("[data-receipt]").forEach(b=>b.onclick=()=>printReceipt(b.dataset.receipt));
  const search=document.getElementById("member-search");
  if(search) search.oninput=()=>{const q=search.value.toLowerCase();document.getElementById("members-body").innerHTML=memberRows(db.members.filter(m=>(m.name+" "+m.phone+" "+m.activity).toLowerCase().includes(q)))};
  const mobile=document.getElementById("mobile-menu"); if(mobile) mobile.onclick=()=>document.getElementById("sidebar").classList.toggle("open");
  const saveSettings=document.getElementById("save-settings"); if(saveSettings) saveSettings.onclick=()=>{alert("Paramètres enregistrés.");};
  document.querySelectorAll(".more-btn[data-member]").forEach(b=>b.onclick=()=>alert("Fiche membre prête pour les actions avancées : modifier, renouveler ou supprimer."));
}
window.addEventListener("hashchange",render);
render();
