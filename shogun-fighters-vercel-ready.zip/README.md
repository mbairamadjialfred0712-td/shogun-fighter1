# Shogun Fighters — Vercel-ready prototype

Prototype SPA inspiré de la vue globale Lovable fournie.

## Déploiement Vercel
Aucune commande de build n'est nécessaire : le projet est une SPA statique.
- Framework Preset: Other
- Build Command: vide
- Output Directory: `.`
- Install Command: vide

Le `vercel.json` contient le rewrite SPA pour éviter les 404 sur les routes.

## Fonctionnalités prototype
- Dashboard global
- Membres
- Abonnements
- Paiements
- Activités
- Reçus imprimables
- Notifications d'expiration
- Entrées / sorties
- Statistiques
- Paramètres
- Ajout de membre et enregistrement de paiement
- Persistance locale via localStorage

Les données sont volontairement locales pour rester un prototype sans backend.
